import React, { useState } from 'react';
import './FinalResults.css';

const calculateDecision = (e1, e2, e3) => {
  const diff = Math.abs(e1 - e2);
  let moyenne = 0;

  if (diff <= 3) {
    moyenne = (e1 + e2) / 2;
  } else {
    const closest = Math.abs(e1 - e3) <= Math.abs(e2 - e3) ? e1 : e2;
    moyenne = (closest + e3) / 2;
  }

  return {
    moyenne: parseFloat(moyenne.toFixed(3)),
    decision: moyenne >= 10 ? 'Admis(e)' : 'Ajourné(e)'
  };
};

const mockData = [
  { id: 42, nom: 'MECHTAB', prenom: 'khawla', epreuve1: 6.00, epreuve2: 9.75, epreuve3: 0, moyenne: 8.813, decision: 'Admis(e)' },
  { id: 155, nom: 'ZEROULOU', prenom: 'amal', epreuve1: 8.00, epreuve2: 8.50, epreuve3: 0, moyenne: 8.375, decision: 'Admis(e)' },
  { id: 43, nom: 'MESSAS', prenom: 'Abir', epreuve1: 12.00, epreuve2: 7.00, epreuve3: 0, moyenne: 8.25, decision: 'Admis(e)' }
];

const FinalResults = () => {
  const [data, setData] = useState(
    [...mockData].sort((a, b) => b.moyenne - a.moyenne)
  );
  const [editing, setEditing] = useState(null);
  const [formData, setFormData] = useState({});

  const handleEditClick = (student) => {
    setEditing(student.id);
    setFormData({ ...student });
  };

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSave = () => {
    const { moyenne, decision } = calculateDecision(
      parseFloat(formData.epreuve1),
      parseFloat(formData.epreuve2),
      parseFloat(formData.epreuve3)
    );

    setData(prev =>
      [...prev.map(el =>
        el.id === editing ? { ...formData, id: el.id, moyenne, decision } : el
      )].sort((a, b) => b.moyenne - a.moyenne)
    );
    setEditing(null);
  };

  const handleUploadNamesOnly = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    window.location.href = '/link-names';
  };

  const handleUploadWithScores = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (event) {
      const text = event.target.result;
      const rows = text.trim().split('\n').map(row => row.split(','));
      const header = rows[0];

      const newData = rows.slice(1).map(row => {
        const obj = {};
        header.forEach((key, i) => {
          obj[key.trim()] = row[i].trim();
        });

        const { moyenne, decision } = calculateDecision(
          parseFloat(obj.epreuve1),
          parseFloat(obj.epreuve2),
          parseFloat(obj.epreuve3)
        );

        return {
          id: parseInt(obj.id),
          nom: obj.nom,
          prenom: obj.prenom,
          epreuve1: parseFloat(obj.epreuve1),
          epreuve2: parseFloat(obj.epreuve2),
          epreuve3: parseFloat(obj.epreuve3),
          moyenne,
          decision
        };
      });

      setData([...data, ...newData].sort((a, b) => b.moyenne - a.moyenne));
    };

    reader.readAsText(file);
  };

  return (
    <div className="final-results">
      <h2>Procès-Verbal Final</h2>

      <div className="upload-panel">
        <button className="upload-btn red" onClick={() => document.getElementById('upload-names').click()}>
          📁 Téléverser noms uniquement
        </button>
        <input type="file" id="upload-names" accept=".csv" hidden onChange={handleUploadNamesOnly} />

        <button className="upload-btn red" onClick={() => document.getElementById('upload-full').click()}>
          📁 Téléverser noms + notes
        </button>
        <input type="file" id="upload-full" accept=".csv" hidden onChange={handleUploadWithScores} />
      </div>

      <table>
        <thead>
          <tr>
            <th>Rang</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Epreuve 1</th>
            <th>Epreuve 2</th>
            <th>Epreuve 3</th>
            <th>Moyenne</th>
            <th>Décision</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((el, index) => (
            <tr key={el.id}>
              <td>{index + 1}</td>
              <td>{el.nom}</td>
              <td>{el.prenom}</td>
              <td>{el.epreuve1}</td>
              <td>{el.epreuve2}</td>
              <td>{el.epreuve3}</td>
              <td>{el.moyenne}</td>
              <td className={el.decision === 'Admis(e)' ? 'success' : 'fail'}>
                {el.decision}
              </td>
              <td>
                <button onClick={() => handleEditClick(el)}>
                  <i className='bx bxs-edit'></i> Modifier
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editing && (
        <div className="modal">
          <div className="modal-content">
            <h3>Modifier Étudiant</h3>
            <input name="nom" value={formData.nom} onChange={handleChange} placeholder="Nom" />
            <input name="prenom" value={formData.prenom} onChange={handleChange} placeholder="Prénom" />
            <input name="epreuve1" value={formData.epreuve1 || ''} onChange={handleChange} type="number" step="0.01" />
            <input name="epreuve2" value={formData.epreuve2 || ''} onChange={handleChange} type="number" step="0.01" />
            <input name="epreuve3" value={formData.epreuve3 || ''} onChange={handleChange} type="number" step="0.01" />
            <div className="modal-buttons">
              <button onClick={handleSave}>Enregistrer</button>
              <button onClick={() => setEditing(null)}>Annuler</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FinalResults;
