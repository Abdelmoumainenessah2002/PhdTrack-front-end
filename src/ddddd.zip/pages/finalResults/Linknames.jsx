import React, { useState } from 'react';
import './LinkNames.css';

const mockStudents = [
  { id: 1, nom: 'Sidi Ali', prenom: 'Abderrahmane', naissance: '1991-05-16', epreuve1: 0.25, epreuve2: 0.25, epreuve3: '', moyenne: 0.25 },
  { id: 2, nom: 'Brahimi', prenom: 'Karim', naissance: '1990-11-23', epreuve1: '', epreuve2: '', epreuve3: '', moyenne: '' },
  { id: 3, nom: 'Benali', prenom: 'Lamia', naissance: '1992-02-12', epreuve1: '', epreuve2: '', epreuve3: '', moyenne: '' }
];

const LinkNames = () => {
  const [students, setStudents] = useState(mockStudents);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');

  const handleSelect = (student) => {
    setSelected({ ...student });
  };

  const handleChange = (e) => {
    setSelected(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSave = () => {
    setStudents(prev =>
      prev.map(s => s.id === selected.id ? selected : s)
    );
    alert('Modifications enregistrées');
  };

  const filtered = students.filter(s =>
    `${s.nom} ${s.prenom}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="link-names-container">
      <h2>Associer les candidats</h2>

      {selected && (
        <div className="edit-box">
          <h3>Modifier les informations</h3>
          <input name="nom" value={selected.nom} onChange={handleChange} placeholder="Nom" />
          <input name="prenom" value={selected.prenom} onChange={handleChange} placeholder="Prénom" />
          <input name="naissance" value={selected.naissance} onChange={handleChange} type="date" />
          <input name="epreuve1" value={selected.epreuve1} onChange={handleChange} placeholder="Epreuve 1" />
          <input name="epreuve2" value={selected.epreuve2} onChange={handleChange} placeholder="Epreuve 2" />
          <input name="epreuve3" value={selected.epreuve3} onChange={handleChange} placeholder="Epreuve 3" />
          <input name="moyenne" value={selected.moyenne} onChange={handleChange} placeholder="Moyenne" />
          <button onClick={handleSave}>Enregistrer</button>
        </div>
      )}

      <input
        type="text"
        placeholder="Rechercher un candidat..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="search-box"
      />

      <div className="students-list">
        {filtered.map(student => (
          <div key={student.id} className="student-item" onClick={() => handleSelect(student)}>
            {student.nom} {student.prenom} - {student.naissance}
          </div>
        ))}
      </div>
    </div>
  );
};

export default LinkNames;
